import java.util.Locale;
import java.util.Scanner;

public class UrnaEletronica {

    private final Eleicao eleicao;
    private final Tela tela;
    private EstadoVotacao estadoVotacao;

    private int cargoAtualIndex;
    private String digitacaoAtual;

    // Sequência de encerramento: três votos "999" confirmados
    private int contagemEncerramento;

    public UrnaEletronica(Eleicao eleicao, Tela tela) {
        this.eleicao = eleicao;
        this.tela = tela;
        this.estadoVotacao = EstadoVotacao.INICIANDO;
        this.cargoAtualIndex = 0;
        this.digitacaoAtual = "";
        this.contagemEncerramento = 0;
    }

    public EstadoVotacao getEstadoVotacao() {
        return estadoVotacao;
    }

    public void setupEleicaoPadraoSeVazia() {
        if (eleicao.quantidadeCargos() > 0) return;

        // Cargos padrão conforme especificação do projeto.
        Cargo c1 = new Cargo("CDI-CEA");
        Cargo c2 = new Cargo("CONGRAD");
        Cargo c3 = new Cargo("CUNI");

        // Exemplos de candidatos (podem ser removidos se o professor exigir cadastro manual).
        c1.adicionarCandidato(new Candidato("Candidato A", 10, "Chapa 1"));
        c1.adicionarCandidato(new Candidato("Candidato B", 11, "Chapa 2"));

        c2.adicionarCandidato(new Candidato("Candidato C", 20, "Chapa 1"));
        c2.adicionarCandidato(new Candidato("Candidato D", 21, "Chapa 2"));

        c3.adicionarCandidato(new Candidato("Candidato E", 30, "Chapa 1"));
        c3.adicionarCandidato(new Candidato("Candidato F", 31, "Chapa 2"));

        eleicao.adicionarCargo(c1);
        eleicao.adicionarCargo(c2);
        eleicao.adicionarCargo(c3);
    }

    public void iniciarVotacao() {
        if (eleicao.quantidadeCargos() == 0) {
            throw new IllegalStateException("Não há cargos cadastrados. Cadastre antes de iniciar.");
        }
        estadoVotacao = EstadoVotacao.VOTANDO;
        cargoAtualIndex = 0;
        digitacaoAtual = "";
        contagemEncerramento = 0;
        tela.mostrarMensagem("Votação iniciada.");
    }

    public void encerrarVotacao() {
        estadoVotacao = EstadoVotacao.ENCERRADA;
        tela.mostrarMensagem("Votação encerrada.");
    }

    public String emitirRelatorioFinal() {
        if (estadoVotacao != EstadoVotacao.ENCERRADA) {
            throw new IllegalStateException("Relatório só pode ser emitido após ENCERRAR a votação.");
        }
        Relatorio relatorio = new Relatorio();
        return relatorio.gerarBoletimDeUrna(eleicao);
    }

    private Cargo cargoAtual() {
        return eleicao.getCargo(cargoAtualIndex);
    }

    private boolean isNumeroValido(String s) {
        return s != null && s.matches("\\d+");
    }

    private void limparDigitacao() {
        digitacaoAtual = "";
    }

    private void proximoCargoOuFim() {
        cargoAtualIndex++;
        limparDigitacao();

        if (cargoAtualIndex >= eleicao.quantidadeCargos()) {
            tela.mostrarFim();
            // Após um eleitor concluir, reinicia para próximo eleitor (mantém votação aberta)
            cargoAtualIndex = 0;
            limparDigitacao();
            tela.mostrarMensagem("Próximo eleitor.");
        }
    }

    private void processarConfirmacaoVoto(Cargo cargo) {
        // Sequência de encerramento: voto 999 confirmado (3 vezes)
        if ("999".equals(digitacaoAtual)) {
            contagemEncerramento++;
            tela.mostrarMensagem("Sequência de encerramento: " + contagemEncerramento + "/3");
            limparDigitacao();
            if (contagemEncerramento >= 3) {
                encerrarVotacao();
            }
            return;
        }

        contagemEncerramento = 0; // reseta se não for 999

        if (digitacaoAtual.isEmpty()) {
            // Nada digitado => interpretamos como nulo ao confirmar
            cargo.registrarVotoNulo();
            tela.mostrarVotoNulo();
            proximoCargoOuFim();
            return;
        }

        if (!isNumeroValido(digitacaoAtual)) {
            cargo.registrarVotoNulo();
            tela.mostrarVotoNulo();
            proximoCargoOuFim();
            return;
        }

        int numero = Integer.parseInt(digitacaoAtual);
        Candidato candidato = cargo.buscarCandidatoPorNumero(numero);

        if (candidato == null) {
            cargo.registrarVotoNulo();
            tela.mostrarVotoNulo();
        } else {
            cargo.registrarVotoValido(numero);
            tela.mostrarMensagem("Voto registrado.");
        }

        proximoCargoOuFim();
    }

    public void executarLoopPrincipal() {
        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.US);

        tela.mostrarMensagem("Sistema de Urna Eletrônica Simplificada");
        tela.mostrarMensagem("Digite ADMIN para configurações. Digite SAIR para encerrar o programa.");

        while (true) {
            if (estadoVotacao == EstadoVotacao.VOTANDO) {
                Cargo cargo = cargoAtual();
                tela.mostrarCabecalhoCargo(cargo.getNome());
                tela.mostrarDigitacaoAtual(digitacaoAtual);

                if (digitacaoAtual.isEmpty()) {
                    tela.mostrarMensagem("Digite o número do candidato (ou BRANCO).");
                } else if (isNumeroValido(digitacaoAtual)) {
                    int num = Integer.parseInt(digitacaoAtual);
                    Candidato cand = cargo.buscarCandidatoPorNumero(num);
                    if (cand != null) tela.mostrarCandidato(cand);
                    else tela.mostrarVotoNulo();
                } else {
                    tela.mostrarVotoNulo();
                }

                tela.mostrarMenuTeclas();
                String cmd = sc.nextLine().trim();

                if (cmd.equalsIgnoreCase("SAIR")) {
                    tela.mostrarMensagem("Encerrando o programa.");
                    break;
                }
                if (cmd.equalsIgnoreCase("ADMIN")) {
                    modoAdmin(sc);
                    continue;
                }
                if (cmd.equalsIgnoreCase("CORRIGE")) {
                    limparDigitacao();
                    continue;
                }
                if (cmd.equalsIgnoreCase("BRANCO")) {
                    cargo.registrarVotoBranco();
                    tela.mostrarVotoBranco();
                    proximoCargoOuFim();
                    continue;
                }
                if (cmd.equalsIgnoreCase("CONFIRMA")) {
                    processarConfirmacaoVoto(cargo);
                    continue;
                }

                // Caso contrário, tenta tratar como número digitado (sobrescreve digitacaoAtual)
                // Aceita digitação em partes (ex: "1" depois "0" -> "10") se usuário digitar um dígito por vez.
                if (cmd.matches("\\d")) {
                    digitacaoAtual += cmd;
                } else if (cmd.matches("\\d+")) {
                    digitacaoAtual = cmd;
                } else {
                    tela.mostrarMensagem("Entrada inválida.");
                }

            } else if (estadoVotacao == EstadoVotacao.ENCERRADA) {
                tela.mostrarMensagem("Estado: ENCERRADA.");
                tela.mostrarMensagem("Digite RELATORIO para emitir, ADMIN para editar dados, ou SAIR.");
                String cmd = sc.nextLine().trim();

                if (cmd.equalsIgnoreCase("SAIR")) {
                    tela.mostrarMensagem("Encerrando o programa.");
                    break;
                }
                if (cmd.equalsIgnoreCase("RELATORIO")) {
                    try {
                        String rel = emitirRelatorioFinal();
                        System.out.println(rel);
                    } catch (Exception e) {
                        tela.mostrarMensagem("Erro: " + e.getMessage());
                    }
                    continue;
                }
                if (cmd.equalsIgnoreCase("ADMIN")) {
                    modoAdmin(sc);
                    continue;
                }

                tela.mostrarMensagem("Comando inválido.");
            } else {
                // INICIANDO
                tela.mostrarMensagem("Estado: INICIANDO. Digite ADMIN para configurar ou INICIAR para começar votação.");
                String cmd = sc.nextLine().trim();

                if (cmd.equalsIgnoreCase("SAIR")) {
                    tela.mostrarMensagem("Encerrando o programa.");
                    break;
                }
                if (cmd.equalsIgnoreCase("ADMIN")) {
                    modoAdmin(sc);
                    continue;
                }
                if (cmd.equalsIgnoreCase("INICIAR")) {
                    try {
                        iniciarVotacao();
                    } catch (Exception e) {
                        tela.mostrarMensagem("Erro: " + e.getMessage());
                    }
                    continue;
                }

                tela.mostrarMensagem("Comando inválido.");
            }
        }

        sc.close();
    }

    private void modoAdmin(Scanner sc) {
        while (true) {
            tela.mostrarMenuAdmin();
            String opt = sc.nextLine().trim();

            if ("5".equals(opt) || opt.equalsIgnoreCase("VOLTAR")) {
                return;
            }

            switch (opt) {
                case "1":
                    tela.mostrarMensagem("Nome do cargo:");
                    String nomeCargo = sc.nextLine().trim();
                    if (nomeCargo.isEmpty()) {
                        tela.mostrarMensagem("Nome inválido.");
                        break;
                    }
                    eleicao.adicionarCargo(new Cargo(nomeCargo));
                    tela.mostrarMensagem("Cargo cadastrado.");
                    break;

                case "2":
                    if (eleicao.quantidadeCargos() == 0) {
                        tela.mostrarMensagem("Não há cargos cadastrados.");
                        break;
                    }
                    tela.mostrarMensagem("Escolha o índice do cargo:");
                    for (int i = 0; i < eleicao.quantidadeCargos(); i++) {
                        tela.mostrarMensagem(i + ") " + eleicao.getCargo(i).getNome());
                    }
                    String idxStr = sc.nextLine().trim();
                    if (!idxStr.matches("\\d+")) {
                        tela.mostrarMensagem("Índice inválido.");
                        break;
                    }
                    int idx = Integer.parseInt(idxStr);
                    Cargo cargo = eleicao.getCargo(idx);
                    if (cargo == null) {
                        tela.mostrarMensagem("Índice inválido.");
                        break;
                    }

                    tela.mostrarMensagem("Nome do candidato:");
                    String nome = sc.nextLine().trim();
                    tela.mostrarMensagem("Número do candidato (inteiro):");
                    String numStr = sc.nextLine().trim();
                    tela.mostrarMensagem("Partido/Chapa:");
                    String partido = sc.nextLine().trim();

                    if (nome.isEmpty() || partido.isEmpty() || !numStr.matches("\\d+")) {
                        tela.mostrarMensagem("Dados inválidos.");
                        break;
                    }

                    int numero = Integer.parseInt(numStr);
                    try {
                        cargo.adicionarCandidato(new Candidato(nome, numero, partido));
                        tela.mostrarMensagem("Candidato cadastrado.");
                    } catch (Exception e) {
                        tela.mostrarMensagem("Erro: " + e.getMessage());
                    }
                    break;

                case "3":
                    try {
                        iniciarVotacao();
                        return; // sai do admin e volta ao loop (votação)
                    } catch (Exception e) {
                        tela.mostrarMensagem("Erro: " + e.getMessage());
                    }
                    break;

                case "4":
                    try {
                        String rel = emitirRelatorioFinal();
                        System.out.println(rel);
                    } catch (Exception e) {
                        tela.mostrarMensagem("Erro: " + e.getMessage());
                    }
                    break;

                default:
                    tela.mostrarMensagem("Opção inválida.");
                    break;
            }
        }
    }
}
