public enum EstadoVotacao {
    INICIANDO,
    VOTANDO,
    ENCERRADA
}
