import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Eleicao {
    private final List<Cargo> cargos;

    public Eleicao() {
        this.cargos = new ArrayList<>();
    }

    public void adicionarCargo(Cargo cargo) {
        if (cargo == null) return;
        cargos.add(cargo);
    }

    public List<Cargo> getCargos() {
        return Collections.unmodifiableList(cargos);
    }

    public Cargo getCargo(int indice) {
        if (indice < 0 || indice >= cargos.size()) return null;
        return cargos.get(indice);
    }

    public int quantidadeCargos() {
        return cargos.size();
    }
}
