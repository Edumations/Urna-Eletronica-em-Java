import java.util.Comparator;
import java.util.List;

public class Relatorio {

    public String gerarBoletimDeUrna(Eleicao eleicao) {
        StringBuilder sb = new StringBuilder();
        sb.append("=========== BOLETIM DE URNA ===========\n\n");

        for (Cargo cargo : eleicao.getCargos()) {
            sb.append("CARGO: ").append(cargo.getNome()).append("\n");
            sb.append("--------------------------------------\n");

            List<Candidato> candidatos = cargo.getCandidatos();
            candidatos.stream()
                    .sorted(Comparator.comparingInt(Candidato::getTotalVotos).reversed())
                    .forEach(c -> sb.append(String.format("%-25s (%d) - %-10s : %d voto(s)\n",
                            c.getNome(), c.getNumero(), c.getPartido(), c.getTotalVotos())));

            sb.append(String.format("Votos em BRANCO: %d\n", cargo.getVotosBrancos()));
            sb.append(String.format("Votos NULOS    : %d\n", cargo.getVotosNulos()));
            sb.append("\n");
        }

        sb.append("======================================\n");
        return sb.toString();
    }
}
