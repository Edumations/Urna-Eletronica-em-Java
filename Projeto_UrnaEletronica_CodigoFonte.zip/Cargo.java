import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Cargo {
    private final String nome;
    private final List<Candidato> candidatos;
    private int votosBrancos;
    private int votosNulos;

    public Cargo(String nome) {
        this.nome = nome;
        this.candidatos = new ArrayList<>();
        this.votosBrancos = 0;
        this.votosNulos = 0;
    }

    public String getNome() {
        return nome;
    }

    public void adicionarCandidato(Candidato candidato) {
        if (candidato == null) return;
        // Evita números duplicados dentro do mesmo cargo.
        if (buscarCandidatoPorNumero(candidato.getNumero()) != null) {
            throw new IllegalArgumentException("Já existe candidato com este número neste cargo.");
        }
        candidatos.add(candidato);
    }

    public Candidato buscarCandidatoPorNumero(int numero) {
        for (Candidato c : candidatos) {
            if (c.getNumero() == numero) return c;
        }
        return null;
    }

    public void registrarVotoValido(int numero) {
        Candidato c = buscarCandidatoPorNumero(numero);
        if (c == null) {
            registrarVotoNulo();
            return;
        }
        c.incrementarVoto();
    }

    public void registrarVotoBranco() {
        votosBrancos++;
    }

    public void registrarVotoNulo() {
        votosNulos++;
    }

    public int getVotosBrancos() {
        return votosBrancos;
    }

    public int getVotosNulos() {
        return votosNulos;
    }

    public List<Candidato> getCandidatos() {
        return Collections.unmodifiableList(candidatos);
    }
}
