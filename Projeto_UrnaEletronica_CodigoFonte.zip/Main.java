public class Main {
    public static void main(String[] args) {
        Eleicao eleicao = new Eleicao();
        Tela tela = new Tela();
        UrnaEletronica urna = new UrnaEletronica(eleicao, tela);

        // Se quiser começar com cargos/candidatos padrão, mantenha esta linha.
        // Se o professor exigir cadastro manual, pode comentar/remover.
        urna.setupEleicaoPadraoSeVazia();

        urna.executarLoopPrincipal();
    }
}
