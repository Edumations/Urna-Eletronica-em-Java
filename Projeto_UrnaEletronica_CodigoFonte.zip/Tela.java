public class Tela {

    public void mostrarMensagem(String msg) {
        System.out.println(msg);
    }

    public void mostrarCabecalhoCargo(String nomeCargo) {
        System.out.println();
        System.out.println("========================================");
        System.out.println("CARGO: " + nomeCargo);
        System.out.println("========================================");
    }

    public void mostrarDigitacaoAtual(String digitacao) {
        System.out.println("Número digitado: " + (digitacao.isEmpty() ? "(vazio)" : digitacao));
    }

    public void mostrarCandidato(Candidato candidato) {
        System.out.println("CANDIDATO ENCONTRADO:");
        System.out.println("Nome   : " + candidato.getNome());
        System.out.println("Número : " + candidato.getNumero());
        System.out.println("Partido: " + candidato.getPartido());
    }

    public void mostrarVotoBranco() {
        System.out.println("VOTO EM BRANCO");
    }

    public void mostrarVotoNulo() {
        System.out.println("VOTO NULO");
    }

    public void mostrarFim() {
        System.out.println();
        System.out.println("FIM");
        System.out.println("\u0007"); // beep (pode não tocar em alguns terminais)
    }

    public void mostrarMenuTeclas() {
        System.out.println();
        System.out.println("[Opções] DIGITE: número | BRANCO | CORRIGE | CONFIRMA");
        System.out.println("[Admin ] ADMIN | SAIR");
    }

    public void mostrarMenuAdmin() {
        System.out.println();
        System.out.println("===== MODO ADMINISTRADOR =====");
        System.out.println("1) Cadastrar cargo");
        System.out.println("2) Cadastrar candidato em um cargo");
        System.out.println("3) Iniciar votação");
        System.out.println("4) Emitir relatório (se ENCERRADA)");
        System.out.println("5) Voltar");
    }
}
