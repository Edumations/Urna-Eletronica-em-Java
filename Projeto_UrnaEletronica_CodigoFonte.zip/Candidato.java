public class Candidato {
    private final String nome;
    private final int numero;
    private final String partido;
    private int totalVotos;

    public Candidato(String nome, int numero, String partido) {
        this.nome = nome;
        this.numero = numero;
        this.partido = partido;
        this.totalVotos = 0;
    }

    public void incrementarVoto() {
        totalVotos++;
    }

    public String getNome() {
        return nome;
    }

    public int getNumero() {
        return numero;
    }

    public String getPartido() {
        return partido;
    }

    public int getTotalVotos() {
        return totalVotos;
    }

    @Override
    public String toString() {
        return String.format("%s (%d) - %s", nome, numero, partido);
    }
}
